package com.suppasek.mycondo.activity

import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.content.Context
import kotlinx.android.synthetic.main.activity_main.*
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.View
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.suppasek.mycondo.fragment.HomeFragment
import com.suppasek.mycondo.fragment.LoginFragment
import com.suppasek.mycondo.fragment.PackageFragment
import com.suppasek.mycondo.R
import com.aurelhubert.ahbottomnavigation.AHBottomNavigationAdapter
import com.suppasek.mycondo.fragment.WaterFragment
import com.suppasek.mycondo.viewmodel.MainActivityViewModel

class MainActivity : AppCompatActivity() {

    private var homeFragment = HomeFragment()
    private var auth = FirebaseAuth.getInstance()
    var user : FirebaseUser? = auth.currentUser
    var room : String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (isUserSignedIn()) {
            bottom_menu.visibility = View.INVISIBLE
            switchFragment(LoginFragment())
        }
        else {
            setInitialLayout()
        }
    }

    fun setInitialLayout() {
        bottom_menu.visibility = View.VISIBLE
        getRoomFromSharedPreference()
        switchFragment(homeFragment)
        setNavMenu()
        subscribeArrivePackage()
    }

    //observe data from view model and set package noti
    fun subscribeArrivePackage() {
        ViewModelProviders.of(this).get(MainActivityViewModel(room)::class.java)
                .notifyPackageData()
                .observe(this, Observer {
                    packageAmount ->
                    setPackageNoti(packageAmount!!)
                })
    }

    private fun isUserSignedIn() : Boolean {
        return user != null
    }

    private fun setNavMenu() {
        val navigationAdapter = AHBottomNavigationAdapter(this, R.menu.bottom_menu)
        navigationAdapter.setupWithBottomNavigation(findViewById(R.id.bottom_menu))

        //set home menu by default
        bottom_menu.currentItem = 1
        bottom_menu.defaultBackgroundColor = getColor(R.color.colorPrimary)

        bottom_menu.setOnTabSelectedListener { position, _ ->
            when (position) {
                1 -> {
                    switchFragment(homeFragment)
                    return@setOnTabSelectedListener true
                }
                2 -> {
                    switchFragment(PackageFragment())
                    return@setOnTabSelectedListener true
                }
                0 -> {
                    switchFragment(WaterFragment())
                    return@setOnTabSelectedListener true
                }
                else -> {
                    return@setOnTabSelectedListener true
                }
            }
        }
    }

    private fun switchFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction().replace(R.id.main_view, fragment).commit()
    }

    private fun getRoomFromSharedPreference() {
        val sp = getSharedPreferences("myCondoPreference", Context.MODE_PRIVATE)
        room = sp.getString("room", "0")
    }

    private fun setPackageNoti(size : Int) {
            bottom_menu.setNotification(size.toString(), 2)
    }
}
