package com.suppasek.mycondo.fragment


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.firebase.firestore.FirebaseFirestore
import com.suppasek.mycondo.adapter.AnnounceAdapter
import com.suppasek.mycondo.R
import com.suppasek.mycondo.model.Announce
import kotlinx.android.synthetic.main.fragment_home.*

class HomeFragment : Fragment() {

    private val firestore = FirebaseFirestore.getInstance()
    private var announces = ArrayList<Announce>()
    private var announceAdapter = AnnounceAdapter()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        setProgressBar(true)
        getData()
        setRecyclerView()
    }

    private fun getData() {
        announces.clear()
        firestore.collection("announce").orderBy("recordNo").get().addOnSuccessListener {documents ->
            for (document in documents) {
                announces.add(document.toObject(Announce::class.java))
            }

            setProgressBar(false)
            announceAdapter.notifyDataSetChanged()
            if (announces.size == 0) home_nothing.visibility = View.VISIBLE

        }.addOnFailureListener {
            setProgressBar(false)
            home_nothing.visibility = View.VISIBLE
        }
    }

    private fun setRecyclerView() {
        home_announce_list.layoutManager = LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false)
        announceAdapter.setItemList(announces)
        home_announce_list.adapter = announceAdapter
    }

    private fun setProgressBar(switch : Boolean) {
        if (switch && home_progress_bar != null) {
            home_progress_bar.visibility = View.VISIBLE
        }
        else if (home_progress_bar != null) {
            home_progress_bar.visibility = View.INVISIBLE
        }
    }
}