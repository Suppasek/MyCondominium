package com.suppasek.mycondo.model

data class Announce (val tag: String = "",
                     val body: String = "",
                     val announceNo: Int = 0)
