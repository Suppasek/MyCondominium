package com.suppasek.mycondo.model

data class Package(val name : String = "",
                   val packageNo : String = "",
                   val recordNo : Int = 0,
                   val verify : String = "",
                   val status : String = "")