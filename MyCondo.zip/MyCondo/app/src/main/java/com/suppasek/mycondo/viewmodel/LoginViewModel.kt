package com.suppasek.mycondo.viewmodel

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class LoginViewModel : ViewModel() {

    private val auth = FirebaseAuth.getInstance()
    private val firestore = FirebaseFirestore.getInstance()
    var room : MutableLiveData<String> = MutableLiveData()

    fun authen(username: String, password: String): LiveData<String> {
        val exception : MutableLiveData<String> = MutableLiveData()

        auth.signInWithEmailAndPassword(username, password).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                getRoomData()
            } else {
                exception.postValue(task.exception.toString())
            }
        }
        return exception
    }

    private fun getRoomData() : LiveData<String> {
        firestore.collection("users")
                .document(auth.currentUser!!.uid)
                .get()
                .addOnCompleteListener { task ->
                    room.postValue(task.result?.get("room").toString())
                }

        return room
    }


}