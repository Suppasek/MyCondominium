package com.suppasek.mycondo.viewmodel

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivityViewModel(var room: String?) : ViewModel() {

    private var auth = FirebaseAuth.getInstance()
    private val firestore = FirebaseFirestore.getInstance()

    //get amount of arrive package
    fun notifyPackageData() : LiveData<Int> {
        val packageAmount : MutableLiveData<Int> = MutableLiveData()

        firestore.collection("rooms")
                .document("house_no $room")
                .collection("package")
                .whereEqualTo("status", "pending")
                .get()
                .addOnSuccessListener {documents ->

                    //in case package aren't arrive shouldn't show notification 'zero'
                    if (documents.size() > 0) {
                        packageAmount.postValue(documents.size())
                    }
                }

        return packageAmount
    }
}